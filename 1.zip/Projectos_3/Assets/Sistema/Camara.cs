using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camara : MonoBehaviour
{
     [Space(10)]
    public float velocidadPaneo = 20f;
    public float velocidadRotacion = 60f;
    public float gruesoBordePaneo = 10f;
     [Space(10)]
    public Vector2 limitePaneo;
     [Space(10)]
    public float velocidadDesplazamiento = 20f;
    public float minY = 20f;
    public float maxY = 120f;

    public GameObject brazoCamara;


    Vector3 rotacion;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Movimiento_Paneo();
        Movimiento_Rotacion();
    }

    void Movimiento_Paneo()
    {
        try
        {
            Vector3 pos_camara = brazoCamara.transform.position;

            
            if (Input.mousePosition.y >= Screen.height - gruesoBordePaneo)
            {
                pos_camara.z += velocidadPaneo * Time.deltaTime;
            }
            if (Input.mousePosition.y <= gruesoBordePaneo)
            {
                pos_camara.z -= velocidadPaneo * Time.deltaTime;
            }
            if (Input.mousePosition.x >= Screen.width - gruesoBordePaneo)
            {
                pos_camara.x += velocidadPaneo * Time.deltaTime;
            }
            if (Input.mousePosition.x <= gruesoBordePaneo)
            {
                pos_camara.x -= velocidadPaneo * Time.deltaTime;
            }

            float desplazamiento = Input.GetAxis("Mouse ScrollWheel");
            pos_camara.y -= desplazamiento * velocidadDesplazamiento * 100f * Time.deltaTime;

            pos_camara.x = Mathf.Clamp(pos_camara.x, -limitePaneo.x, limitePaneo.x);
            pos_camara.y = Mathf.Clamp(pos_camara.y, minY, maxY);
            pos_camara.z = Mathf.Clamp(pos_camara.z, -limitePaneo.y, limitePaneo.y);

            brazoCamara.transform.position = pos_camara;     
        }
        catch
        {
            DebugController.Mensaje(Enum_Mensaje.Error, "CLASS: Camara - METODO: Movimiento_Paneo()");
        }
    }

    void Movimiento_Rotacion()
    {
        try
        {
            if (Input.GetKey("w"))
            {
                rotacion = new Vector3( -velocidadRotacion, 0.0f, 0.0f);
            }
            else if(Input.GetKey("s"))
            {
                rotacion = new Vector3(velocidadRotacion, 0.0f, 0.0f);
            }
            
            
            else
            {
                rotacion = new Vector3(0.0f, 0.0f, 0.0f);
            }

            transform.Rotate(rotacion * Time.deltaTime);
        }
        catch
        {

        }
    }
}
