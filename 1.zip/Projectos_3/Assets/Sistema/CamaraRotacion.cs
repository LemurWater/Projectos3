using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CamaraRotacion : MonoBehaviour
{
    public float velocidadRotacion;

    Vector3 rotacion_camara;
    Vector3 rotacion_brujula;
    [Space(10)]
    public GameObject camara;
    public GameObject brujula;
    public GameObject escenario;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Movimiento_Rotacion();
    }
    public void Movimiento_Rotacion()
    {
        if(Input.GetKey("a"))
        {
            rotacion_camara = new Vector3(0.0f, -velocidadRotacion, 0.0f);
            rotacion_brujula = new Vector3(0.0f, 0.0f, velocidadRotacion);
        }
        else if(Input.GetKey("d"))
        {
            rotacion_camara = new Vector3(0.0f, velocidadRotacion, 0.0f);
            rotacion_brujula = new Vector3(0.0f, 0.0f, -velocidadRotacion);
        }
        else
        {
            rotacion_camara = new Vector3(0.0f, 0.0f, 0.0f);
            rotacion_brujula = new Vector3(0.0f, 0.0f, 0.0f);
        }

            escenario.transform.Rotate(rotacion_camara * Time.deltaTime);
            brujula.transform.Rotate(rotacion_brujula * Time.deltaTime);
    }
}
