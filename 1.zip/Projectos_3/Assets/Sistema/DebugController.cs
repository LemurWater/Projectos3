using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Enum_Errores 
{ 
    Usuario, 
    programa
}
public enum Enum_Mensaje
{
    Informacion,
    Sugerencia,
    Error,
}


public class DebugController : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        Mensaje(Enum_Mensaje.Error, "'ERROR' test");
        Mensaje(Enum_Mensaje.Informacion, "'INFORMACION' test");
        Mensaje(Enum_Mensaje.Sugerencia, "'SUGERENMCIA' test");
    }

    // Update is called once per frame
    void Update()
    {

    }

    public static bool Mensaje(Enum_Mensaje tipo, string texto)
    { 
        try
        {
            string color = "";
            switch(tipo)
            {   
                case Enum_Mensaje.Error:
                color = "<size=15><color=red><b>  ERROR  </b></color></size>";
                break;
                
                case Enum_Mensaje.Informacion:
                color = "<size=12><color=magenta><b>  INFORMACION  </b></color></size>";
                break;

                case Enum_Mensaje.Sugerencia:
                color = "<size=10><color=cyan><b>  SUGERENCIA  </b></color></size>";
                break;
            }
            color += "<color=yellow><size=15><b> ㅡ  </b></size></color>";

            Debug.Log(color + texto);
            return true;
        }
        catch
        {
            return false;
        }
    }
}
