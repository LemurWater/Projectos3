using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;



public class BotonDinamico : MonoBehaviour
{
    public TipoDinamico tipoDinamico;
     [Space(20)]
    public List<GameObject> personas;
     [Space(10)]
    public Material color1;
    public Material color2;
    public Material color3;
    public Material color4;
    public Material color5;
    public Material color0;
    [Space(10)]
    public byte cantidad1;
    public byte cantidad2;
    public byte cantidad3;
    public byte cantidad4;
    public byte cantidad5;
    [Space(10)]
    public BotonValor bv1;
    public BotonValor bv2;
    public BotonValor bv3;
    public BotonValor bv4;
    public BotonValor bv5;
     [Space(20)]
    public BotonPresentacion botonPresentacion;
    public List<GameObject> goPresentacion2_1;
    public List<GameObject> goPresentacion2_2;
    public List<GameObject> goPresentacion2_3;
    public List<GameObject> goPresentacion2_4;
    public List<GameObject> goPresentacion2_5;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    public void Clickeado()
    {
        try
        {
            botonPresentacion.tipoDinamico = tipoDinamico;

            switch (botonPresentacion.tipoPresentacion)
            {
                case TipoPresentacion.Presentacion_1:
                    {
                        if (bv1.estado1)
                        {
                            foreach (GameObject go in goPresentacion2_1)
                            {
                                go.GetComponent<MeshRenderer>().material = color1;
                                go.transform.localScale = new Vector3(200f, 200f, 200f);
                               go.transform.localPosition = new Vector3(
                                go.transform.localPosition.x, 7f, go.transform.localPosition.z);
                            }
                        }
                        else
                        {
                            foreach (GameObject go in goPresentacion2_1)
                            {
                                go.GetComponent<MeshRenderer>().material = color0;
                                go.transform.localScale = new Vector3(100f, 100f, 100f);
                                go.transform.localPosition = new Vector3(
                                  go.transform.localPosition.x, 3.15f, go.transform.localPosition.z);
                            }
                        }
                        if (bv2.estado1)
                        {
                            foreach (GameObject go in goPresentacion2_2)
                            {
                                go.GetComponent<MeshRenderer>().material = color2;
                                go.transform.localScale = new Vector3(260f, 260f, 260f);
                                go.transform.localPosition = new Vector3(
                                   go.transform.localPosition.x, 9.2f, go.transform.localPosition.z);
                            }
                        }
                        else
                        {
                            foreach (GameObject go in goPresentacion2_2)
                            {
                                go.GetComponent<MeshRenderer>().material = color0;
                                go.transform.localScale = new Vector3(100f, 100f, 100f);
                                go.transform.localPosition = new Vector3(
                                    go.transform.localPosition.x, 3.15f, go.transform.localPosition.z);
                            }
                        }
                        if (bv3.estado1)
                        {
                            foreach (GameObject go in goPresentacion2_3)
                            {
                                go.GetComponent<MeshRenderer>().material = color3;
                                go.transform.localScale = new Vector3(320f, 320f, 320f);
                                go.transform.localPosition = new Vector3(
                                   go.transform.localPosition.x, 11f, go.transform.localPosition.z);
                            }
                        }
                        else
                        {
                            foreach (GameObject go in goPresentacion2_3)
                            {
                                go.GetComponent<MeshRenderer>().material = color0;
                                go.transform.localScale = new Vector3(100f, 100f, 100f);
                                go.transform.localPosition = new Vector3(
                                    go.transform.localPosition.x, 3.15f, go.transform.localPosition.z);
                            }
                        }
                        if (bv4.estado1)
                        {
                            foreach (GameObject go in goPresentacion2_4)
                            {
                                go.GetComponent<MeshRenderer>().material = color4;
                                go.transform.localScale = new Vector3(380f, 380f, 380f);
                                go.transform.localPosition = new Vector3(
                                   go.transform.localPosition.x, 13.7f, go.transform.localPosition.z);
                            }
                        }
                        else
                        {
                            foreach (GameObject go in goPresentacion2_4)
                            {
                                go.GetComponent<MeshRenderer>().material = color0;
                                go.transform.localScale = new Vector3(100f, 100f, 100f); 
                                go.transform.localPosition = new Vector3(
                                    go.transform.localPosition.x, 3.15f, go.transform.localPosition.z);
                            }
                        }
                        if (bv5.estado1)
                        {
                            foreach (GameObject go in goPresentacion2_5)
                            {
                                go.GetComponent<MeshRenderer>().material = color5;
                                go.transform.localScale = new Vector3(440f, 440f, 440f);
                                go.transform.localPosition = new Vector3(
                                    go.transform.localPosition.x, 15.5f, go.transform.localPosition.z);
                            }
                        }
                        else
                        {
                            foreach (GameObject go in goPresentacion2_5)
                            {
                                go.GetComponent<MeshRenderer>().material = color0;
                                go.transform.localScale = new Vector3(100f, 100f, 100f);
                                go.transform.localPosition = new Vector3(
                                    go.transform.localPosition.x, 3.15f, go.transform.localPosition.z);
                            }
                        }
                        break;
                    }
                    

                case TipoPresentacion.Presentacion_2:
                    {
                        byte contador = 0;

                        foreach(GameObject go in personas)
                        {
                            go.transform.localScale = new Vector3(100f, 100f, 100f);
                        }
                        if (bv1.estado2 == true)
                        {
                            for (byte i = 0; i <= cantidad1; i++)
                            {
                                personas[contador].GetComponent<MeshRenderer>().material = color1;
                                contador++;
                            }
                        }
                        if (bv2.estado2 == true)
                        {
                            for (byte i = 0; i <= cantidad2; i++)
                            {
                                personas[contador].GetComponent<MeshRenderer>().material = color2;
                                contador++;
                            }
                        }

                        if (bv3.estado2 == true)
                        {
                            for (byte i = 0; i <= cantidad3; i++)
                            {
                                personas[contador].GetComponent<MeshRenderer>().material = color3;
                                contador++;
                            }
                        }
                        if (bv4.estado2 == true)
                        {
                            for (byte i = 0; i <= cantidad4; i++)
                            {
                                personas[contador].GetComponent<MeshRenderer>().material = color4;
                                contador++;
                            }
                        }
                        if (bv5.estado2 == true)
                        {
                            for (byte i = 0; i <= cantidad5; i++)
                            {
                                personas[contador].GetComponent<MeshRenderer>().material = color5;
                                contador++;
                            }
                        }
                        for (byte i = contador; i < 100; i++)
                        {
                            personas[i].GetComponent<MeshRenderer>().material = color0;
                        }
                        break;
                    }
            }
        }
        catch
        {
            
        }
    }
}
