using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class BotonValor : MonoBehaviour
{
    public bool estado1 = false;
    public bool estado2 = false;
     [Space(10)]
    public BotonDinamico botonDinamico1;
    public BotonDinamico botonDinamico2;
    public BotonDinamico botonDinamico3;
     [Space(10)]
    public TextMeshProUGUI texto;
    public ModuloTres moduloTres;
    public BotonPresentacion botonPresentacion;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Clickeado()
    {
        try
        {
            Cambiar_Estado();
            Actualizar();
        }
        catch
        {
            
        }
    }
    void Actualizar()
    {
        try
        {
            switch (moduloTres.activo)
            {
                case DinamicoActivo.Percepcion:
                    botonDinamico1.Clickeado();
                    break;

                case DinamicoActivo.Estado:
                    botonDinamico2.Clickeado();
                    break;

                case DinamicoActivo.Frecuencia:
                    botonDinamico3.Clickeado();
                    break;
            }
        }
        catch
        {

        }
    }
    public void Actualizar_Estado()
    {
        switch (botonPresentacion.tipoPresentacion)
        {
            case TipoPresentacion.Presentacion_1:
                switch (estado1)
                {
                    case true:
                        texto.text = "+";
                        break;

                    case false:
                        texto.text = "-";
                        break;
                }
                break;
            case TipoPresentacion.Presentacion_2:
                switch (estado2)
                {
                    case true:
                        texto.text = "+";
                        break;

                    case false:
                        texto.text = "-";
                        break;
                }
                break;
        }
    }
    public void Cambiar_Estado()
    {
        try
        {
            switch (botonPresentacion.tipoPresentacion)
            {
                case TipoPresentacion.Presentacion_1:
                    switch (estado1)
                    {
                        case true:
                            estado1 = false;
                            break;

                        case false:
                            estado1 = true;
                            break;
                    }
                    break;

                case TipoPresentacion.Presentacion_2:
                    switch (estado2)
                    {
                        case true:
                            estado2 = false;
                            break;

                        case false:
                            estado2 = true;
                            break;
                    }
                    break;
            }
            Actualizar_Estado();
        }
        catch
        {

        }
    }
}
