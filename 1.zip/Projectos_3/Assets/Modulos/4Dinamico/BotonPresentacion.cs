using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public enum TipoPresentacion
{
    Presentacion_1,
    Presentacion_2
}

public enum TipoDinamico
{
    PercepcionDeSeguridad,
    EstadoDelImnueble,
    FrecuenciaDeVisitas
}
public class BotonPresentacion : MonoBehaviour
{
    public TipoPresentacion tipoPresentacion;
    [Space(10)]
    public GameObject presentacion1;
    public GameObject presentacion2;
    [Space(10)]
    public BotonDinamico[] botonDinamico;
    public Material color0;
    public List<BotonValor> botonesValor;

    public TipoDinamico tipoDinamico;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
   

    public void Clickeado()
    {
        try
        {
            
            Vector3 rotacion;

            switch (tipoPresentacion)
            {
                case TipoPresentacion.Presentacion_1:
                {
                     tipoPresentacion = TipoPresentacion.Presentacion_2;
                        presentacion1.SetActive(false);
                        presentacion2.SetActive(true);
                        rotacion = new Vector3(0f, 0f, 180f);
                        transform.Rotate(rotacion);
                        
                        break;
                }
                case TipoPresentacion.Presentacion_2:
                    tipoPresentacion=TipoPresentacion.Presentacion_1;
                    presentacion1.SetActive(true);
                    presentacion2.SetActive(false);
                    rotacion = new Vector3(0f, 0f, -180f);
                    transform.Rotate(rotacion);
                    break;
            }
            foreach (GameObject go in botonDinamico[0].personas)
            {
                go.GetComponent<MeshRenderer>().material = color0;
                go.transform.localScale = new Vector3(100f, 100f, 100f);
            }
            foreach(BotonValor bv in botonesValor)
            {
                bv.Actualizar_Estado();
            }

            switch (tipoDinamico)
            {
                case TipoDinamico.PercepcionDeSeguridad:
                    botonDinamico[0].Clickeado();
                    break;

                case TipoDinamico.EstadoDelImnueble:
                    botonDinamico[1].Clickeado();
                    break;

                case TipoDinamico.FrecuenciaDeVisitas:
                    botonDinamico[2].Clickeado();
                    break;
            }
        }
        catch
        {

        }
    }
}
