using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;

public class ClickBoton : MonoBehaviour
{
    public GameObject imagen;
    public List<GameObject> l_imagenes;

    public GameObject go_todos;
    public GameObject go_singular;
     [Space(10)]
    public string nombre;
    public string texto;

    public Text go_nombre;
    public Text go_texto;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Clickeado()
    {
        try
        {
            go_todos.SetActive(false);
            go_singular.SetActive(true);

            imagen.SetActive(true);
            foreach(GameObject go in l_imagenes)
            {
                if(go != imagen)
                {
                    go.SetActive(false);
                }
            }
            go_nombre.text = nombre;
            go_texto.text = texto;

        }
        catch
        {

        }
    }
}
