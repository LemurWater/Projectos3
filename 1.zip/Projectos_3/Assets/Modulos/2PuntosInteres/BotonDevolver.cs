using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class BotonDevolver : MonoBehaviour
{
    public GameObject todos;
    public GameObject singular;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Seleccionado()
    {
        todos.SetActive(true);
        singular.SetActive(false);
    }
}
