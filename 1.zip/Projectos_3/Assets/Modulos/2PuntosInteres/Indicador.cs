using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;


public enum Enum_Indicador
{
    Imagen,
    Audio,
    Video
}
public class Indicador : MonoBehaviour
{
    private Transform camara;
    public Enum_Indicador tipo;
    public string nombre;
    public string texto;

    public float distanciaRayo = 400f;
     [Space(20)]
    public GameObject go_todos;
    public GameObject go_singular;
    public GameObject go_imagen;
    public GameObject[] go_imagenesSinUsar;
     [Space(5)]
    public Text go_nombre;
    public Text go_texto;
     [Space(10)]
    //public Image imagen;
    public AudioSource audio;
    // Start is called before the first frame update
    void Start()
    {
        camara = Camera.main.transform;
    }

    // Update is called once per frame
    void Update()
    {
        transform.LookAt(camara);

        ClickMouse();
        
    }

    void ClickMouse()
    {
        try
        {
            if (Input.GetMouseButtonDown(0))
            {
                RaycastHit hit;
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

                if(Physics.Raycast(ray, out hit, distanciaRayo))
                {
                    if(hit.transform == this.transform)
                    {
                        Debug.Log("CLICK TEST - " + name);
                        go_singular.SetActive(true);
                        go_todos.SetActive(false);

                        go_nombre.text = nombre;
                        go_texto.text = texto;
                      
                        MostrarInfo();
                    }
                }
            }
        }
        catch
        {

        }

    }

    void MostrarInfo()
    {
        try
        {
            //Mostrar imagen video
            switch(tipo)
            {
                case Enum_Indicador.Imagen:
                go_imagen.SetActive(true);
                foreach(GameObject go in go_imagenesSinUsar)
                {
                    if(go != go_imagen)
                    {
                        go.SetActive(false);
                    }
                }
                break;

                case Enum_Indicador.Audio:
                audio.Play();
                go_singular.SetActive(false);
                go_todos.SetActive(true);
                break;

                case Enum_Indicador.Video:
                    GameObject camera = GameObject.Find("Camara");
                    var videoPlayer = camera.AddComponent<UnityEngine.Video.VideoPlayer>();
                    videoPlayer.isLooping = false;
                    videoPlayer.Play();
                    go_singular.SetActive(false);
                    go_todos.SetActive(true);
                    //videoPlayer.Stop();
                break;
            }
        }
        catch
        {

        }
    }
}
