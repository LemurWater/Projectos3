using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;

public class AMappingOpacidad : MonoBehaviour
{    
    public List<Renderer> l_areas;
    public Material material;
    private Slider slider;
    private Color color;


    // Start is called before the first frame update
    void Start()
    {
        slider = GetComponent<Slider>();
        slider.onValueChanged.AddListener(delegate {ValorCambiado(); });

        color = material.color;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void ValorCambiado()
    {
        try
        {
            /*color.a = (int)slider.value;
            material.SetColor("color", color);*/
            foreach(Renderer r in l_areas)
            {
                Color color = material.color;
                color.a = slider.value;
                r.material.color = color;
            }
            
        }
        catch
        {

        }
    }
}
