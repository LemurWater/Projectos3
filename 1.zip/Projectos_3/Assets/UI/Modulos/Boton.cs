using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;

public enum TipoBoton
{
    Capas,
    PuntosInteres,
    Diagramas,
    Dinamico
}
public class Boton : MonoBehaviour
{
    public TipoBoton tipoBoton;
     [Space(10)]
    public List<GameObject> esteHUD;
    public List<GameObject> otroHUD;
     [Space(5)]
    public GameObject capas;
    public GameObject pInteres;
    public GameObject pInteres_TODOS;
    public GameObject pInteres_SINGULAR;

    public GameObject diagramas;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Clickeado()
    {
        try
        {
            switch(tipoBoton)
            {
                case TipoBoton.Capas:
                    pInteres.SetActive(false);
                    capas.SetActive(true);
                    diagramas.SetActive(false);
                    break;

                case TipoBoton.PuntosInteres:
                    capas.SetActive(false);
                    pInteres.SetActive(true);
                    pInteres_TODOS.SetActive(true);
                    pInteres_SINGULAR.SetActive(false);
                    diagramas.SetActive(false);
                    break;
                
                case TipoBoton.Diagramas:
                    break;

                case TipoBoton.Dinamico:
                    diagramas.SetActive(true);
                    capas.SetActive(false);
                    pInteres.SetActive(false);
                    break;
            }
        }
        catch
        {

        }
    }
}
