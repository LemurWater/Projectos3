using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class ControladorSistema : MonoBehaviour
{
    public GameObject ui;

    public List<GameObject> desactivar_test;
    public List<GameObject> activar_test;


    // Start is called before the first frame update
    void Start()
    {
        ui.SetActive(true);
        Desactivar_Todos();
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void Desactivar_Todos()
    {
        try
        {
            foreach(GameObject go in desactivar_test)
            {
                go.SetActive(false);
            }
        }
        catch
        {

        }
    }
    void Activar_Todos()
    {
        try
        {
            foreach(GameObject go in activar_test)
            {
                go.SetActive(true);
            }
        }
        catch
        {

        }
    }
}
