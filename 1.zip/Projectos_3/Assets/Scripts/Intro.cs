using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Intro : MonoBehaviour
{
    public GameObject pantallaIntro;

    public GameObject modulos_3d;
    public GameObject modulos_ui;

    public GameObject pestanas;
    public GameObject mapping;

    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(Contador());
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    IEnumerator Contador()
    {
        yield return new WaitForSeconds(3);

        modulos_ui.SetActive(true);
        modulos_3d.SetActive(true);
        pestanas.SetActive(true);
        mapping.SetActive(true);

        pantallaIntro.SetActive(false);
    }
}
