using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test : MonoBehaviour
{
    //test01()
    public GameObject t01_go_capa;
    public Transform t01_pos;

    //test02()


    // Start is called before the first frame update
    void Start()
    {
        Test01();
    }

    // Update is called once per frame
    void Update()
    {
        Test02();
    }

    public bool Test01()
    {
        try
        {
            Instantiate(t01_go_capa, new Vector3(t01_pos.position.x, t01_pos.position.y, t01_pos.position.z), Quaternion.identity);
            return true;
        }
        catch
        {
            return false;
        }
    }

    public bool Test02()
    {
        try
        {
            return true;
        }
        catch
        {
            return false;
        }
    }
}
