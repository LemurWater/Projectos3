using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarroController : MonoBehaviour
{
    [Space(10)]
    public Transform default_pos; 
    public float speed = 2f;
    

    //
    [Space(50)]
    public int timer = 1160;
    [Space(10)]
    public int contador = 0;
    // Start is called before the first frame update
    void Start()
    {
        transform.position = default_pos.position;
    }

    // Update is called once per frame
    void Update()
    {
        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");
        // Vector3 movement = new Vector3(x, 0, z);
        Vector3 movement = new Vector3(1, 0, 0);

        transform.Translate(movement * speed * Time.deltaTime);
        contador++;


        if (contador >= timer)
        {
            transform.position = default_pos.position;
            contador = 0;
        }      
    }
}
